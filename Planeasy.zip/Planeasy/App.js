import React from 'react';
import AppNavigation from './screens/AppNavigation';

export default function App() {
  return <AppNavigation />;
}